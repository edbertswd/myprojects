const axios = require('axios');

class PokemonService {
  constructor() {
    this.baseURL = 'https://api.pokemontcg.io/v2';
    this.apiKey = process.env.POKEMON_TCG_API_KEY;
    
    // Default headers
    this.headers = {
      'Content-Type': 'application/json'
    };
    
    // Temporarily disable API key for testing
    // if (this.apiKey) {
    //   this.headers['X-Api-Key'] = this.apiKey;
    // }

    // Your card collection (you'll customize this)
    this.myCollection = [
      { id: 'base1-4', quantity: 1 }, 
    ];
  }

  // Update your collection (you'll use this to manage your cards)
  updateCollection(collection) {
    this.myCollection = collection;
  }

  // Get multiple cards by their IDs
  async getCardsByIds(cardIds) {
    try {
      const promises = cardIds.map(async (cardData) => {
        const cardId = typeof cardData === 'string' ? cardData : cardData.id;
        const quantity = typeof cardData === 'object' ? cardData.quantity : 1;
        
        try {
          console.log(`🔍 Fetching card: ${cardId}`);
          const response = await axios.get(`${this.baseURL}/cards/${cardId}`, {
            headers: this.headers
          });
          
          console.log(`✅ Found card: ${response.data.data.name}`);
          return {
            ...response.data.data,
            quantity: quantity
          };
        } catch (cardError) {
          console.error(`❌ Card not found: ${cardId} (${cardError.response?.status})`);
          return null; // Return null for missing cards instead of throwing
        }
      });

      const cards = await Promise.all(promises);
      const validCards = cards.filter(card => card !== null);
      console.log(`📋 Successfully fetched ${validCards.length}/${cardIds.length} cards`);
      
      return validCards;
    } catch (error) {
      console.error('Error fetching cards by IDs:', error.message);
      throw error;
    }
  }

  // Get your collection cards
  async getMyCollection() {
    try {
      return await this.getCardsByIds(this.myCollection);
    } catch (error) {
      console.error('Error getting my collection:', error.message);
      throw error;
    }
  }

  // Get featured cards (rare/special cards from your collection)
  async getFeaturedCards(limit = 6) {
    try {
      const collection = await this.getMyCollection();
      
      // Sort by rarity and market value (featured = rare/expensive cards)
      const featured = collection
        .filter(card => {
          const isRare = card.rarity && ['Rare', 'Ultra Rare', 'Secret Rare', 'Rainbow Rare'].includes(card.rarity);
          const isSpecial = card.subtypes && card.subtypes.includes('EX') || card.subtypes && card.subtypes.includes('GX');
          return isRare || isSpecial;
        })
        .sort((a, b) => {
          // Sort by TCGPlayer market price if available
          const aPrice = a.tcgplayer?.prices?.holofoil?.market || a.tcgplayer?.prices?.normal?.market || 0;
          const bPrice = b.tcgplayer?.prices?.holofoil?.market || b.tcgplayer?.prices?.normal?.market || 0;
          return bPrice - aPrice;
        })
        .slice(0, limit);

      return featured.length > 0 ? featured : collection.slice(0, limit);
    } catch (error) {
      console.error('Error getting featured cards:', error.message);
      throw error;
    }
  }

  // Get random cards from collection
  async getRandomCards(count = 3) {
    try {
      const collection = await this.getMyCollection();
      const shuffled = collection.sort(() => 0.5 - Math.random());
      return shuffled.slice(0, count);
    } catch (error) {
      console.error('Error getting random cards:', error.message);
      throw error;
    }
  }

  // Get collection stats
  async getCollectionStats() {
    try {
      const collection = await this.getMyCollection();
      
      const stats = {
        totalCards: collection.reduce((sum, card) => sum + (card.quantity || 1), 0),
        uniqueCards: collection.length,
        totalValue: 0,
        rarityBreakdown: {},
        typeBreakdown: {},
        setBreakdown: {}
      };

      collection.forEach(card => {
        // Calculate total value
        const cardValue = card.tcgplayer?.prices?.holofoil?.market || 
                         card.tcgplayer?.prices?.normal?.market || 0;
        stats.totalValue += cardValue * (card.quantity || 1);

        // Rarity breakdown
        const rarity = card.rarity || 'Unknown';
        stats.rarityBreakdown[rarity] = (stats.rarityBreakdown[rarity] || 0) + (card.quantity || 1);

        // Type breakdown
        if (card.types) {
          card.types.forEach(type => {
            stats.typeBreakdown[type] = (stats.typeBreakdown[type] || 0) + (card.quantity || 1);
          });
        }

        // Set breakdown
        const setName = card.set?.name || 'Unknown';
        stats.setBreakdown[setName] = (stats.setBreakdown[setName] || 0) + (card.quantity || 1);
      });

      return stats;
    } catch (error) {
      console.error('Error getting collection stats:', error.message);
      throw error;
    }
  }

  // Search for cards (for adding to collection)
  async searchCards(query, options = {}) {
    try {
      const params = {
        q: query,
        page: options.page || 1,
        pageSize: options.pageSize || 20,
        ...options.filters
      };

      console.log('🔍 Searching cards with params:', params);
      console.log('🌐 API URL:', `${this.baseURL}/cards`);
      console.log('📋 Headers:', this.headers);

      // Let's also log the full URL that will be called
      const url = new URL(`${this.baseURL}/cards`);
      Object.entries(params).forEach(([key, value]) => {
        url.searchParams.append(key, value);
      });
      console.log('🔗 Full URL:', url.toString());

      const response = await axios.get(`${this.baseURL}/cards`, {
        headers: this.headers,
        params: params,
        timeout: 10000 // 10 second timeout
      });

      console.log('✅ Search successful, found:', response.data.totalCount, 'cards');

      return {
        cards: response.data.data,
        totalCount: response.data.totalCount,
        page: response.data.page,
        pageSize: response.data.pageSize,
        totalPages: Math.ceil(response.data.totalCount / response.data.pageSize)
      };
    } catch (error) {
      console.error('❌ Error searching cards:', error.message);
      if (error.response) {
        console.error('📊 Response status:', error.response.status);
        console.error('📝 Response data:', error.response.data);
        console.error('📋 Response headers:', error.response.headers);
      }
      if (error.request) {
        console.error('📡 Request was made but no response:', error.request);
      }
      throw error;
    }
  }

  // Get card sets (for browsing)
  async getSets(options = {}) {
    try {
      const params = {
        page: options.page || 1,
        pageSize: options.pageSize || 50
      };

      const response = await axios.get(`${this.baseURL}/sets`, {
        headers: this.headers,
        params: params
      });

      return response.data;
    } catch (error) {
      console.error('Error getting sets:', error.message);
      throw error;
    }
  }
}

module.exports = new PokemonService();